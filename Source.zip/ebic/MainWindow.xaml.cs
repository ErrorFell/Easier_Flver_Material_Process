﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace ebic
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public OpenFileDialogForm x = new OpenFileDialogForm();
        public string[] Banned;
        public string[] HelmB = { "P_Ghost_FDP.mtd", "P_Ghost_FDP_Cloth.mtd", "P[ARSN]_e_Decal.mtd", "P[ARSN]_Decal.mtd", "P_HD[ARSN].mtd", "P_HD[ARSN]_e.mtd", "P_HD[ARSN]_e_Cloth.mtd" };
        public string[] ChestB = { "P_Ghost_FDP_Cloth.mtd", "P_Ghost_FDP.mtd", "P_BD[ARSN].mtd", "P_BD[ARSN]_e.mtd", "P_BD[ARSN]_e_Cloth.mtd", "P[ARSN]_e_Decal.mtd", "P[ARSN]_Decal.mtd" };
        public string[] GloveB = { "P_Ghost_FDP.mtd", "P_Ghost_FDP_Cloth.mtd", "P_AM[ARSN]_e.mtd", "P_AM[ARSN].mtd", "P_AM[ARSN]_e_Cloth.mtd", "P[ARSN]_e_Decal.mtd", "P[ARSN]_Decal.mtd" };
        public string[] LegB = { "P_Ghost_FDP.mtd", "P_Ghost_FDP_Cloth.mtd", "P[ARSN]_e_Decal.mtd", "P[ARSN]_Decal.mtd", "P_LG[ARSN].mtd", "P_LG[ARSN]_e.mtd", "P_LG[ARSN]_e_Cloth.mtd" };
        public string[] WepB = { "P_Ghost_FDP.mtd", "P_Ghost_FDP_Cloth.mtd", "P[ARSN]_e_Decal.mtd", "P[ARSN]_Decal.mtd", "P_WP[ARSN].mtd", "P_WP[ARSN]_e.mtd", "P_WP[ARSN]_e_Cloth.mtd" };
        public string[] g_Diffuse = { "SAT_MultiBlend2_BlendOpacity_Equip_Cm_snp_Texture2D_1_GSBlendMap_AlbedoMap_0",
            "SAT_MultiBlend2_BlendOpacity_Equip_Cm_snp_Texture2D_2_GSBlendMap_AlbedoMap_1",
            "SAT_Equip_snp_Texture2D_5_AlbedoMap_0" };
        public string[] g_BumpmapTexture = { "SAT_MultiBlend2_BlendOpacity_Equip_Cm_snp_Texture2D_13_GSBlendMap_NormalMap_0",
            "SAT_MultiBlend2_BlendOpacity_Equip_Cm_snp_Texture2D_14_GSBlendMap_NormalMap_1",
            "SAT_Equip_snp_Texture2D_4_NormalMap_0" };
        public string[] g_SpecularMap = { "SAT_MultiBlend2_BlendOpacity_Equip_Cm_snp_Texture2D_5_GSBlendMap_ReflectanceMap_0",
            "SAT_MultiBlend2_BlendOpacity_Equip_Cm_snp_Texture2D_6_GSBlendMap_ReflectanceMap_1",
            "SAT_Equip_snp_Texture2D_3_ReflectanceMap_0" };
        public string filecontent = "";
        public string filepath = "";

        public IEnumerable<T> FindVisualChildren<T>(DependencyObject depObj) where T : DependencyObject
        {
            if (depObj != null)
            {
                for (int i = 0; i < VisualTreeHelper.GetChildrenCount(depObj); i++)
                {
                    DependencyObject child = VisualTreeHelper.GetChild(depObj, i);
                    if (child != null && child is T)
                    {
                        yield return (T)child;
                    }

                    foreach (T childOfChild in FindVisualChildren<T>(child))
                    {
                        yield return childOfChild;
                    }
                }
            }
        }

        public bool isMatch<T>(T[] array, T Item)
        {
            foreach (T cont in array)
            {
                if (Convert.ToString(cont) == Convert.ToString(Item))
                    return true;
            }
            return false;
        }

        public string isMatchRTItem<T>(T[] array, T Item)
        {
            for (int i = 0; i < array.Length; i++)
            {
                if (Convert.ToString(array[i]) == Convert.ToString(Item))
                    return Convert.ToString(array[1]);
            }
            return string.Empty;
        }

        public MainWindow()
        {
            InitializeComponent();
            Helmet.Click += new RoutedEventHandler(Change);
            Chestplate.Click += new RoutedEventHandler(Change);
            Gloves.Click += new RoutedEventHandler(Change);
            Legs.Click += new RoutedEventHandler(Change);
            Wep.Click += new RoutedEventHandler(Change);
            Export.Click += new RoutedEventHandler(Apply);
        }

        private void Apply(object sender, RoutedEventArgs e)
        {
            if (filecontent != "" && Banned[0] != "")
            {
                foreach (string b in Banned)
                    filecontent = filecontent.Replace(b, "P[ARSN].mtd");

                foreach (string d in g_Diffuse)
                    filecontent = filecontent.Replace(d, "g_DiffuseTexture");

                foreach (string d in g_BumpmapTexture)
                    filecontent = filecontent.Replace(d, "g_BumpmapTexture");

                foreach (string d in g_SpecularMap)
                    filecontent = filecontent.Replace(d, "g_SpecularMap");

                if (ReplaceM.IsChecked == true && Mname.Text != "BD_M_6050, test")
                {
                    string[] sp = Mname.Text.Split(',');
                    filecontent = filecontent.Replace(sp[0], sp[1]);
                }

                SaveFileDialog saveFileDialog1 = new SaveFileDialog();
                saveFileDialog1.InitialDirectory = @"C:\";
                saveFileDialog1.Title = "Save text Files";
                saveFileDialog1.CheckPathExists = true;
                saveFileDialog1.DefaultExt = "txt";
                saveFileDialog1.Filter = "Text files (*.txt)|*.txt|Json (*.json)|*.json|All files (*.*)|*.*";
                saveFileDialog1.FilterIndex = 2;
                saveFileDialog1.FileName = "Exported_File";
                saveFileDialog1.RestoreDirectory = true;

                if (saveFileDialog1.ShowDialog() == Convert.ToBoolean(System.Windows.Forms.DialogResult.OK))
                {
                    Debug.WriteLine(saveFileDialog1.FileName);
                    FileStream fs = new FileStream(saveFileDialog1.FileName, FileMode.Create);
                    byte[] bytes = Encoding.UTF8.GetBytes(filecontent);
                    fs.Write(bytes, 0, bytes.Length);
                }
            }
            else
                MessageBox.Show("You haven't specified a File to Modify with the \"Select File\" Button.");
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            x.ShowDialog();
            filepath = x.openFileDialog1.FileName;
            filecontent = x.textBox1.Text;
        }

        private void Change(object sender, RoutedEventArgs e)
        {
            CheckBox t = (sender as CheckBox);
            if (Convert.ToBoolean(t.IsChecked))
            {
                foreach (CheckBox tb in FindVisualChildren<CheckBox>(Win))
                {
                    if (tb.Name != t.Name && tb.Name != ReplaceM.Name)
                        tb.Visibility = Visibility.Hidden;
                }

                switch (t.Name)
                {
                    case "Helmet":
                        Banned = HelmB;
                        break;

                    case "Chestplate":
                        Banned = ChestB;
                        break;

                    case "Gloves":
                        Banned = GloveB;
                        break;

                    case "Legs":
                        Banned = LegB;
                        break;

                    case "Wep":
                        Banned = WepB;
                        break;

                    default:
                        break;
                }
            }
            else
            {
                foreach (CheckBox tb in FindVisualChildren<CheckBox>(Win))
                {
                    tb.Visibility = Visibility.Visible;
                }
            }
        }
    }
}
